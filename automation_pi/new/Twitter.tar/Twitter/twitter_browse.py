import collections
from twitter_constants import *

class TwitterBrowse(object):

    def __init__(self):

        self.con = pymysql.connect(db=db_name,
                      user=db_user,
                      password=db_passwd,
                      charset="utf8mb4",
                      host=db_host)
 
        self.cur  = self.con.cursor() 
        self.insert_query = insert_query

    def main(self):
                dup_list = [] 
                with open('twitter_298.txt', 'r') as f:
                    rows = f.readlines()
                    for row in rows:
                        email_id = row.strip('\n').strip().replace('\r','').replace('@','')
                        if not email_id : continue
                        if email_id : screen_url = "https://twitter.com/"+str(email_id)
                        if not screen_url: continue
                        name = screen_url.split('/')[-1].strip()
                        dup_list.append(screen_url)
                        vals = (str(name),str(screen_url),'keepup','Twitter','related_type',0,str(email_id))
                        if screen_url and  email_id : 
                            self.cur.execute(self.insert_query,vals)
                            self.con.commit()
                print([item for item, count in collections.Counter(dup_list).items() if count > 1])
    def __del__(self):
        self.con.close()
        self.cur.close()


if __name__ == '__main__':
    TwitterBrowse().main()

